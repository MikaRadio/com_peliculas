DROP TABLE IF EXISTS `#__programacion_peliculas`;
